class Vehicle:

    def __init__(self, type, forSale, engine): 
        self.type = type
        self.forSale = forSale
        self.engine = engine