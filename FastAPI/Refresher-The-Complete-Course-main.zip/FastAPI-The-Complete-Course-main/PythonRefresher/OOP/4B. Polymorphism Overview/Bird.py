from Animal import *
class Bird(Animal):


    def talk(self): 
        print('Chirp!')