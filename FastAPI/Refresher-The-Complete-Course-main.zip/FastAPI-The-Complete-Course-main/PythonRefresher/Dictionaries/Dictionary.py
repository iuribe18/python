"""
Dictionaries
"""


user_dictionary = {
    'username': 'codingwithroby',
    'name': 'Eric',
    'age': 32
}


user_dictionary2 = user_dictionary.copy()
user_dictionary2.pop("age")
print(user_dictionary2)






















